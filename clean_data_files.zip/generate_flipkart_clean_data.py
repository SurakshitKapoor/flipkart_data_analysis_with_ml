"""
Synthetic Flipkart-style CLEAN data generator (same records / IDs as the raw set) (Oct 2020 - Oct 2026)
Tables: customers (~25K), products (~5K), orders (~300K), order_items (~585K), returns (~60K)
All data is fictional. Raw files intentionally contain real-world messiness.
"""
import os, string
import numpy as np, pandas as pd

rng = np.random.default_rng(2026)
OUT = '/mnt/user-data/outputs/flipkart_clean_data'
os.makedirs(OUT, exist_ok=True)

START, END = pd.Timestamp('2020-10-01'), pd.Timestamp('2026-10-10')
days = pd.date_range(START, END)
T = len(days); tt = np.arange(T)
DAYS = days.to_numpy()
N_CUST, N_PROD, N_ORD, N_RET = 25000, 5000, 300000, 60000
pick = lambda lst: lst[rng.integers(len(lst))]
logu = lambda lo, hi: float(np.exp(rng.uniform(np.log(lo), np.log(hi))))

# ------------------------------------------------------------------ calendar / seasonality
mm = np.array([0, 1.05, .9, 1.0, .9, .9, .85, .95, 1.0, 1.15, 1.7, 1.35, 1.1])[days.month.to_numpy()]
w = (0.5 + 1.5 * tt / T) * mm
w[(days >= '2021-04-20') & (days <= '2021-06-10')] *= 0.7        # COVID 2nd wave dip
ev = np.array(['None'] * T, dtype=object)
def add_event(name, s, e, boost):
    m = (days >= s) & (days <= e); w[m] *= boost; ev[m] = name
for s, e in [('2020-10-16', '2020-10-21'), ('2021-10-03', '2021-10-10'), ('2022-09-23', '2022-09-30'),
             ('2023-10-08', '2023-10-15'), ('2024-09-27', '2024-10-06'), ('2025-09-23', '2025-10-02'),
             ('2026-09-27', '2026-10-05')]:
    add_event('Big Billion Days', s, e, 2.8)
for s, e in [('2020-11-08', '2020-11-14'), ('2021-10-30', '2021-11-04'), ('2022-10-20', '2022-10-24'),
             ('2023-11-08', '2023-11-12'), ('2024-10-28', '2024-11-01'), ('2025-10-17', '2025-10-21')]:
    add_event('Diwali Sale', s, e, 1.7)
for y in range(2021, 2027):
    add_event('Republic Day Sale', f'{y}-01-17', f'{y}-01-22', 1.8)
    add_event('End of Season Sale', f'{y}-06-25', f'{y}-06-30', 1.4)
    add_event('Big Saving Days', f'{y}-07-29', f'{y}-08-03', 1.5)
for y in range(2020, 2026):
    add_event('Big Shopping Days', f'{y}-12-04', f'{y}-12-08', 1.5)
cdf = np.cumsum(w) / w.sum(); cdf0 = np.r_[0, cdf[:-1]]

# ------------------------------------------------------------------ geography
CITY_SPEC = """Delhi|Delhi|Metro|110001,110016,110024,110045,110075,110092|9
Mumbai|Maharashtra|Metro|400001,400050,400069,400093,400703|7
Bengaluru|Karnataka|Metro|560001,560034,560066,560100,560076|8
Hyderabad|Telangana|Metro|500001,500032,500081,500072|5
Chennai|Tamil Nadu|Metro|600001,600020,600042,600100|4
Kolkata|West Bengal|Metro|700001,700019,700091,700156|4
Pune|Maharashtra|Metro|411001,411014,411045,411057|4.5
Ahmedabad|Gujarat|Metro|380001,380015,380054|3
Gurugram|Haryana|Tier 1|122001,122002,122018|2.5
Noida|Uttar Pradesh|Tier 1|201301,201304,201310|2.5
Ghaziabad|Uttar Pradesh|Tier 1|201001,201010|1.5
Jaipur|Rajasthan|Tier 1|302001,302017,302020|2.2
Lucknow|Uttar Pradesh|Tier 1|226001,226010,226016|2
Chandigarh|Chandigarh|Tier 1|160017,160022|1.2
Indore|Madhya Pradesh|Tier 1|452001,452010|1.8
Kochi|Kerala|Tier 1|682001,682016|1.2
Surat|Gujarat|Tier 1|395001,395007|1.8
Nagpur|Maharashtra|Tier 1|440001,440010|1.4
Coimbatore|Tamil Nadu|Tier 1|641001,641012|1.2
Bhopal|Madhya Pradesh|Tier 1|462001,462016|1.2
Vadodara|Gujarat|Tier 1|390001,390007|1.1
Patna|Bihar|Tier 1|800001,800020|1.5
Kanpur|Uttar Pradesh|Tier 2|208001,208012|1.2
Visakhapatnam|Andhra Pradesh|Tier 2|530001,530016,530017|1.2
Ludhiana|Punjab|Tier 2|141001,141002|1
Nashik|Maharashtra|Tier 2|422001,422005|1
Agra|Uttar Pradesh|Tier 2|282001,282002|.9
Varanasi|Uttar Pradesh|Tier 2|221001,221005|.9
Meerut|Uttar Pradesh|Tier 2|250001,250002|.8
Ranchi|Jharkhand|Tier 2|834001,834002|.8
Bhubaneswar|Odisha|Tier 2|751001,751024|.9
Guwahati|Assam|Tier 2|781001,781005|.8
Dehradun|Uttarakhand|Tier 2|248001,248006|.7
Raipur|Chhattisgarh|Tier 2|492001,492010|.8
Jodhpur|Rajasthan|Tier 2|342001,342003|.6
Amritsar|Punjab|Tier 2|143001,143002|.6
Mysuru|Karnataka|Tier 2|570001,570008|.6
Thiruvananthapuram|Kerala|Tier 2|695001,695014|.7
Madurai|Tamil Nadu|Tier 2|625001,625002|.6
Jabalpur|Madhya Pradesh|Tier 2|482001,482002|.6
Panaji|Goa|Tier 2|403001|.3
Bareilly|Uttar Pradesh|Tier 3|243001,243122|.5
Gorakhpur|Uttar Pradesh|Tier 3|273001,273008|.5
Aligarh|Uttar Pradesh|Tier 3|202001,202002|.4
Moradabad|Uttar Pradesh|Tier 3|244001|.4
Siliguri|West Bengal|Tier 3|734001,734003|.4
Jamshedpur|Jharkhand|Tier 3|831001,831012|.4
Hubballi|Karnataka|Tier 3|580020,580029|.35
Salem|Tamil Nadu|Tier 3|636001,636007|.35
Tirupati|Andhra Pradesh|Tier 3|517501,517502|.35
Bikaner|Rajasthan|Tier 3|334001,334003|.3
Udaipur|Rajasthan|Tier 3|313001,313002|.3
Kota|Rajasthan|Tier 3|324001,324005|.3
Ajmer|Rajasthan|Tier 3|305001,305004|.25
Guntur|Andhra Pradesh|Tier 3|522001,522002|.3
Warangal|Telangana|Tier 3|506002,506001|.25
Belagavi|Karnataka|Tier 3|590001,590006|.25
Bhilai|Chhattisgarh|Tier 3|490006,490020|.25"""
cities = []
for line in CITY_SPEC.splitlines():
    c, s, t, p, wt = line.split('|'); cities.append((c, s, t, p.split(','), float(wt)))
cw = np.array([c[4] for c in cities]); cw /= cw.sum()
TIER_CODE = {'Metro': 0, 'Tier 1': 1, 'Tier 2': 2, 'Tier 3': 3}
REGION = {}
for s in ['Delhi', 'Uttar Pradesh', 'Haryana', 'Punjab', 'Rajasthan', 'Uttarakhand', 'Chandigarh', 'Madhya Pradesh', 'Chhattisgarh']: REGION[s] = 'N'
for s in ['Karnataka', 'Telangana', 'Andhra Pradesh', 'Tamil Nadu', 'Kerala']: REGION[s] = 'S'
for s in ['Maharashtra', 'Gujarat', 'Goa']: REGION[s] = 'W'
for s in ['West Bengal', 'Odisha', 'Assam', 'Bihar', 'Jharkhand']: REGION[s] = 'E'

NAMES = {
 'N': (['Rahul','Amit','Rohit','Vikas','Ankit','Manish','Sandeep','Nitin','Deepak','Arjun','Karan','Gaurav','Vivek','Ashish','Pankaj','Mohit','Sachin','Harsh','Yash','Abhishek','Suresh','Rajesh','Harpreet','Gurpreet','Jaspreet'],
       ['Priya','Neha','Pooja','Anjali','Sneha','Kavita','Ritu','Swati','Shweta','Nisha','Divya','Meenakshi','Simran','Ananya','Komal','Aarti','Harleen','Manpreet'],
       ['Sharma','Verma','Gupta','Singh','Yadav','Kumar','Mishra','Agarwal','Jain','Chauhan','Tiwari','Pandey','Malhotra','Kapoor','Bansal','Saxena','Rawat','Bhatia','Arora','Gill','Sandhu','Dubey']),
 'S': (['Karthik','Suresh','Ramesh','Venkat','Arun','Vijay','Harish','Naveen','Praveen','Sai','Manoj','Ganesh','Srinivas','Raghav','Anil','Prasad','Mohan','Dinesh','Joseph','Thomas','Jithin'],
       ['Lakshmi','Divya','Anitha','Deepa','Swathi','Keerthi','Meena','Priyanka','Revathi','Sowmya','Harini','Nandini','Bhavana','Soumya','Anju','Athira','Merin'],
       ['Reddy','Naidu','Iyer','Iyengar','Nair','Menon','Pillai','Rao','Krishnan','Subramanian','Raman','Kumar','Gowda','Shetty','Murthy','Varma','Joseph','Thomas','Kurian','Babu']),
 'W': (['Rohan','Aditya','Pratik','Omkar','Siddharth','Hardik','Jay','Dhruv','Chirag','Parth','Nikhil','Sagar','Swapnil','Akash','Tejas','Mihir','Kunal'],
       ['Pooja','Isha','Riya','Shruti','Kajal','Bhavna','Mansi','Dhara','Komal','Pallavi','Snehal','Rutuja','Aarti','Hetal'],
       ['Patel','Shah','Mehta','Desai','Joshi','Kulkarni','Patil','Deshmukh','Jadhav','Pawar','More','Shinde','Gaikwad','Thakkar','Modi','Parekh','Chavan','Naik','Kamat','Fernandes',"D'Souza"]),
 'E': (['Subhajit','Sourav','Arnab','Debashish','Abhijit','Anirban','Rajib','Biswajit','Pritam','Amit','Sanjib','Ritwik','Dipankar','Bikash','Manoj','Nabin'],
       ['Moumita','Sreeparna','Ananya','Riya','Debasmita','Sutapa','Payel','Mitali','Puja','Rupali','Sagarika','Barnali','Sunita'],
       ['Banerjee','Chatterjee','Mukherjee','Das','Ghosh','Bose','Sen','Dutta','Roy','Saha','Mondal','Sarkar','Mohanty','Panda','Behera','Nayak','Sahoo','Baruah','Borah','Hazarika','Mahato'])}
COMMON = (['Mohammed','Imran','Salman','Faizan','Arif','Zaid','Irfan'], ['Ayesha','Fatima','Zara','Sana','Nazia','Rukhsar','Shabana'],
          ['Khan','Ansari','Qureshi','Sheikh','Siddiqui','Ali','Mirza'])

# ------------------------------------------------------------------ CUSTOMERS (clean base)
ws = (0.7 + 0.9 * tt / T) * np.sqrt(mm)
sday = np.sort(rng.choice(T, N_CUST, p=ws / ws.sum()))
ci = rng.choice(len(cities), N_CUST, p=cw)
cust_id = np.array([f"CUST{1000001 + i}" for i in range(N_CUST)], dtype=object)
gender = rng.choice(['Male', 'Female', 'Other'], N_CUST, p=[.52, .47, .01])
c_city = np.array([cities[i][0] for i in ci], dtype=object)
c_state = np.array([cities[i][1] for i in ci], dtype=object)
c_tier = np.array([cities[i][2] for i in ci], dtype=object)
c_pin = np.array([pick(cities[i][3]) for i in ci], dtype=object)
names, emails = [], []
DOM = ['gmail.com', 'yahoo.in', 'outlook.com', 'hotmail.com', 'rediffmail.com', 'icloud.com']
DP = [.68, .12, .09, .05, .04, .02]
for i in range(N_CUST):
    pool = COMMON if rng.random() < .06 else NAMES[REGION[c_state[i]]]
    fn = pick(pool[1] if gender[i] == 'Female' else pool[0]); ln = pick(pool[2])
    names.append(f"{fn} {ln}")
    base = f"{fn}{ln}".lower().replace("'", "")
    pat = rng.integers(4)
    em = [f"{fn.lower()}.{ln.lower()}", f"{base}{rng.integers(1, 99)}", f"{fn.lower()}{rng.integers(1970, 2005)}", f"{fn.lower()[0]}{ln.lower()}{rng.integers(1, 999)}"][pat].replace("'", "")
    emails.append(f"{em}@{rng.choice(DOM, p=DP)}")
age = np.clip(np.rint(rng.normal(31, 9, N_CUST)), 18, 70).astype(int)
plus = np.where(rng.random(N_CUST) < .14, 'Yes', 'No').astype(object)
ref = np.full(N_CUST, None, dtype=object)
rm = (rng.random(N_CUST) < .12) & (np.arange(N_CUST) > 50)
ref_idx = (rng.random(N_CUST) * np.arange(N_CUST)).astype(int)
ref[rm] = cust_id[ref_idx[rm]]
tcode_c = np.array([TIER_CODE[t] for t in c_tier])

# ------------------------------------------------------------------ PRODUCTS
sellers = np.array([f"SLR{x}" for x in rng.choice(np.arange(10000, 99999), 450, replace=False)], dtype=object)
MOBILE = {'Samsung': ['Galaxy M34 5G', 'Galaxy A15', 'Galaxy S23 FE', 'Galaxy F54'], 'Apple': ['iPhone 13', 'iPhone 14', 'iPhone 15', 'iPhone 16'],
          'Xiaomi': ['13T', '14 Civi'], 'Redmi': ['Note 12', 'Note 13 Pro', '12C', 'A3'], 'realme': ['Narzo 60', '11x', 'C55', 'P1'],
          'OnePlus': ['Nord CE 3', '12R', '11R', '13'], 'Vivo': ['V29', 'T3', 'Y200', 'V40'], 'OPPO': ['F25 Pro', 'A78', 'Reno 11'],
          'Motorola': ['g54', 'Edge 50 Fusion', 'g34'], 'POCO': ['X6', 'M6 Pro', 'C65'], 'Nothing': ['Phone (2a)'], 'iQOO': ['Z9', 'Neo 9 Pro']}
LAPTOP = {'HP': ['Pavilion 15', '15s', 'Victus 15'], 'Lenovo': ['IdeaPad Slim 3', 'IdeaPad Gaming 3', 'LOQ 15'], 'ASUS': ['Vivobook 15', 'TUF Gaming F15', 'Vivobook Go 14'],
          'Dell': ['Inspiron 15', 'Vostro 3520', 'G15'], 'Acer': ['Aspire 5', 'Nitro V'], 'MSI': ['Thin GF63', 'Modern 14'], 'Apple': ['MacBook Air M2', 'MacBook Air M3', 'MacBook Pro 14']}
COL = ['Black', 'Blue', 'White', 'Grey', 'Red', 'Green', 'Navy Blue', 'Maroon', 'Olive', 'Beige', 'Pink', 'Yellow', 'Silver', 'Gold']
CATS = {  # name: (code, product share, sales share, brands, [(type, lo, hi)], variant kind)
 'Electronics': ('ELE', .14, .15, ['boAt', 'Noise', 'JBL', 'Sony', 'realme', 'OnePlus', 'Mi', 'Ambrane', 'Portronics', 'Boult', 'Zebronics', 'Logitech', 'Samsung', 'LG', 'TP-Link'],
   [('True Wireless Earbuds', 799, 5999), ('Bluetooth Neckband', 599, 2499), ('Over-Ear Wireless Headphones', 999, 9999), ('Bluetooth Speaker', 799, 8999), ('Smartwatch', 1299, 12999), ('Power Bank 20000 mAh', 1199, 2999), ('65W Fast Charger', 699, 2499), ('Smart LED TV 43 inch', 17999, 32999), ('Soundbar', 2999, 15999), ('Wireless Mouse', 399, 1999), ('Wi-Fi Router', 999, 4999), ('Webcam Full HD', 999, 3499), ('USB-C Cable 1m', 199, 599)], 'color'),
 'Home Appliances': ('HAP', .09, .09, ['Prestige', 'Philips', 'Bajaj', 'Havells', 'Pigeon', 'Crompton', 'Usha', 'Butterfly', 'Morphy Richards', 'Kent', 'Eureka Forbes', 'Whirlpool', 'LG', 'Samsung', 'Voltas', 'Hindware'],
   [('Mixer Grinder 750W', 1499, 6999), ('Induction Cooktop', 1299, 3999), ('Electric Kettle 1.5L', 499, 1999), ('Ceiling Fan 1200mm', 1499, 4499), ('Air Cooler 50L', 5999, 14999), ('Steam Iron', 699, 2999), ('Water Purifier RO', 8999, 17999), ('Front Load Washing Machine 7kg', 22999, 36999), ('Refrigerator 253L', 22999, 32999), ('Split AC 1.5 Ton', 32999, 45999), ('Vacuum Cleaner', 3999, 12999), ('Air Fryer 4L', 2999, 8999), ('Room Heater', 999, 3499)], 'color'),
 "Men's Fashion": ('MEN', .15, .16, ['Roadster', 'HRX by Hrithik Roshan', "Levi's", 'Allen Solly', 'Peter England', 'U.S. Polo Assn.', 'Puma', 'Van Heusen', 'Jack & Jones', 'Wrogn', 'Flying Machine', 'Raymond', 'Louis Philippe', 'Pepe Jeans'],
   [('Round Neck T-shirt', 299, 1299), ('Polo T-shirt', 499, 1999), ('Slim Fit Shirt', 599, 2499), ('Slim Fit Jeans', 799, 3499), ('Chinos', 699, 2499), ('Hooded Sweatshirt', 699, 2999), ('Track Pants', 399, 1799), ('Cargo Shorts', 399, 1499), ('Bomber Jacket', 999, 4999), ('Cotton Kurta', 499, 1999)], 'colsize'),
 "Women's Fashion": ('WOM', .15, .16, ['Biba', 'W', 'Libas', 'Anouk', 'Aurelia', 'Max', 'Vero Moda', 'ONLY', 'Global Desi', 'FabIndia', 'Zivame', 'Jockey', 'Sangria', 'Rangriti', 'Tokyo Talkies'],
   [('Cotton Kurta', 399, 2499), ('Anarkali Kurti Set', 799, 3999), ('Printed Saree', 499, 3999), ('Straight Fit Jeans', 699, 2999), ('Top', 299, 1499), ('Maxi Dress', 599, 2999), ('Palazzo Pants', 299, 1299), ('Leggings', 299, 899), ('Lehenga Choli', 1499, 7999), ('Cotton Nightsuit', 399, 1599)], 'colsize'),
 'Footwear': ('FOT', .08, .09, ['Nike', 'Adidas', 'Puma', 'Bata', 'Campus', 'Sparx', 'Skechers', 'Woodland', 'Red Tape', 'Crocs', 'Reebok', 'Liberty', 'Paragon', 'Metro'],
   [('Running Shoes', 799, 7999), ('Casual Sneakers', 599, 4999), ('Sports Shoes', 699, 5999), ('Formal Leather Shoes', 999, 4999), ('Flip Flops', 199, 899), ('Sandals', 299, 1999), ('Heels', 499, 2499), ('Slip-on Loafers', 499, 2499)], 'shoe'),
 'Beauty & Grooming': ('BEA', .07, .08, ['Lakmé', 'Maybelline New York', 'Nivea', 'Mamaearth', 'WOW Skin Science', 'Plum', 'Himalaya', "L'Oréal Paris", 'Dove', 'Neutrogena', 'Biotique', 'The Man Company', 'Beardo', 'Park Avenue'],
   [('Face Wash 100 ml', 149, 449), ('Vitamin C Serum 30 ml', 299, 999), ('Sunscreen SPF 50 50 g', 199, 799), ('Matte Lipstick', 199, 899), ('Kajal', 99, 399), ('Shampoo 340 ml', 199, 599), ('Body Lotion 400 ml', 199, 599), ('Beard Trimmer', 799, 2499), ('Perfume 100 ml', 299, 1999), ('Hair Oil 200 ml', 99, 449), ('Face Moisturizer 50 g', 199, 699)], 'none'),
 'Home & Furniture': ('HOM', .07, .06, ['Wakefit', 'Nilkamal', 'Sleepwell', 'Solimo', 'Cello', 'Milton', 'Godrej Interio', 'Urban Ladder', 'Home Centre', 'Story@Home', "D'Decor", 'Bombay Dyeing', 'Spaces'],
   [('Orthopedic Memory Foam Mattress Queen', 6999, 15999), ('Ergonomic Office Chair', 3999, 12999), ('3-Seater Fabric Sofa', 14999, 32999), ('Study Table', 2499, 6999), ('Cotton Bedsheet Double Bed', 499, 1999), ('Curtains Set of 2', 399, 1999), ('Steel Water Bottle 1L', 299, 899), ('Casserole Set', 799, 2499), ('Wall Shelf', 499, 1999), ('Dinner Set 24 Pieces', 999, 3999), ('Shoe Rack', 899, 2999)], 'color'),
 'Grocery': ('GRO', .07, .10, ['Aashirvaad', 'Tata Sampann', 'Fortune', 'Amul', 'Nestlé', 'Britannia', "Haldiram's", 'Maggi', 'Saffola', 'Patanjali', 'India Gate', 'Tata Tea', 'Dabur', 'MDH', 'Everest', 'Parle', 'Cadbury'],
   [('Whole Wheat Atta 5 kg', 199, 349), ('Basmati Rice 5 kg', 449, 899), ('Sunflower Oil 1 L', 129, 189), ('Toor Dal 1 kg', 139, 219), ('Tea 500 g', 199, 349), ('Instant Noodles Pack of 12', 144, 240), ('Salted Peanuts 400 g', 99, 199), ('Masala Mix 100 g', 49, 129), ('Almonds 500 g', 449, 799), ('Rolled Oats 1 kg', 149, 299), ('Cow Ghee 1 L', 549, 799), ('Biscuits Combo Pack', 99, 299)], 'none'),
 'Toys & Baby': ('TOY', .04, .03, ['LEGO', 'Funskool', 'Hot Wheels', 'Hasbro', 'Mattel', 'Pampers', 'Huggies', "Johnson's Baby", 'MamyPoko', 'Mee Mee', 'Chicco', 'Fisher-Price', 'Barbie'],
   [('Building Blocks Set', 499, 4999), ('Remote Control Car', 499, 2499), ('Board Game', 299, 1499), ('Baby Diapers Pants M 76 pcs', 599, 1099), ('Baby Wipes 72 pcs', 99, 299), ('Soft Toy Teddy', 249, 1299), ('Stroller', 2999, 8999), ('Baby Lotion 200 ml', 149, 399), ('Puzzle Set', 149, 699)], 'none'),
 'Sports & Fitness': ('SPO', .04, .03, ['Boldfit', 'Cosco', 'Nivia', 'Yonex', 'Decathlon', 'Kore', 'SG', 'SS', 'Lifelong', 'Strauss', 'Adidas', 'Puma', 'Vector X'],
   [('Yoga Mat 6 mm', 299, 1299), ('Dumbbell Set 10 kg', 799, 2499), ('Cricket Bat Kashmir Willow', 699, 3499), ('Badminton Racquet', 399, 3999), ('Football Size 5', 399, 1499), ('Resistance Bands Set', 199, 799), ('Skipping Rope', 99, 399), ('Treadmill', 14999, 34999), ('Whey Protein 1 kg', 1499, 3999), ('Gym Gloves', 199, 699), ('Cycle 26T', 5499, 10999)], 'color')}
CAT_ORDER = ['Mobiles', 'Laptops'] + list(CATS.keys())
PSHARE = {'Mobiles': .06, 'Laptops': .04, **{k: v[1] for k, v in CATS.items()}}
SSHARE = {'Mobiles': .04, 'Laptops': .01, **{k: v[2] for k, v in CATS.items()}}
CODES = {'Mobiles': 'MOB', 'Laptops': 'LAP', **{k: v[0] for k, v in CATS.items()}}
cnt_c = {k: int(round(N_PROD * PSHARE[k])) for k in CAT_ORDER}
cnt_c['Electronics'] += N_PROD - sum(cnt_c.values())
cat_sellers = {k: rng.choice(sellers, 60, replace=False) for k in CAT_ORDER}
p_rows = []
used = set()
def fsn(code):
    while True:
        s = code + ''.join(rng.choice(list(string.ascii_uppercase + string.digits), 13))
        if s not in used: used.add(s); return s
for cat in CAT_ORDER:
    for _ in range(cnt_c[cat]):
        if cat == 'Mobiles':
            b = pick(list(MOBILE)); m = pick(MOBILE[b]); stg = pick([128, 256, 512] if b == 'Apple' else [64, 128, 256, 512])
            price = rng.uniform(45000, 125000) if b == 'Apple' else logu(7000, 65000)
            nm = f"{b} {m} ({pick(COL)}, {stg} GB)" if b == 'Apple' else f"{b} {m} ({pick(COL)}, {pick([4, 6, 8, 12])} GB RAM, {stg} GB)"
            noun = 'smartphone'
        elif cat == 'Laptops':
            b = pick(list(LAPTOP)); m = pick(LAPTOP[b])
            price = rng.uniform(95000, 250000) if b == 'Apple' else logu(28000, 140000)
            nm = f"{b} {m} ({pick(['Core i3', 'Core i5', 'Core i7', 'Ryzen 5', 'Ryzen 7'])}, {pick([8, 16, 32])} GB RAM, {pick(['512 GB SSD', '1 TB SSD'])}) Laptop"
            noun = 'laptop'
        else:
            _, _, _, brands, types, var = CATS[cat]
            b = pick(brands); ty, lo, hi = pick(types); price = logu(lo, hi); noun = ty.lower()
            vs = {'color': f"({pick(COL)})", 'colsize': f"({pick(COL)}, {pick(['S', 'M', 'L', 'XL', 'XXL'])})",
                  'shoe': f"({pick(COL)}, UK {pick([6, 7, 8, 9, 10])})", 'none': ''}[var]
            nm = f"{b} {ty} {vs}".strip()
        sp = int(price // 10 * 10 + 9) if price > 200 else int(price)
        d = rng.uniform(.05, .65 if cat in ("Men's Fashion", "Women's Fashion", 'Footwear') else .35)
        mrp = int(max(np.ceil(sp / (1 - d) / 10) * 10 - 1, sp))
        sl = cat_sellers[cat][min(int(rng.pareto(1.5)), 59)]
        rt = round(float(np.clip(rng.normal(4.0, .4), 2.6, 4.9)), 1)
        stock = 0 if rng.random() < .06 else int(rng.integers(5, 600))
        p_rows.append((fsn(CODES[cat]), nm, cat, b, sl, mrp, sp, rt if rng.random() > .05 else np.nan, stock, noun))
prod = pd.DataFrame(p_rows, columns=['product_id', 'product_name', 'category', 'brand', 'seller_id', 'mrp', 'selling_price', 'rating', 'stock_qty', 'noun'])
P = len(prod)
# popularity: Zipf inside category, category weight = sales share; ~4% never sold
pp = np.zeros(P)
for cat in CAT_ORDER:
    ix = np.where(prod.category == cat)[0]
    z = rng.pareto(1.2, len(ix)) + 1; z[rng.random(len(ix)) < .04] = 0
    pp[ix] = SSHARE[cat] * z / z.sum()
pp /= pp.sum()
cat_idx = prod.category.map({c: i for i, c in enumerate(CAT_ORDER)}).to_numpy()

# ------------------------------------------------------------------ ORDERS
tenure = (T - sday) / T
base = rng.lognormal(0, .9, N_CUST) * (.12 + tenure)
no_order = rng.random(N_CUST) < .05; base[no_order] = 0
n = np.minimum(np.rint(base * (N_ORD / base.sum())).astype(int), 150)
n[(~no_order) & (n < 1)] = 1
while n.sum() != N_ORD:
    diff = N_ORD - n.sum()
    if diff > 0:
        ix = rng.choice(np.where(~no_order)[0], min(diff, 5000)); np.add.at(n, ix, 1)
    else:
        cand = np.where(n > 1)[0]; ix = rng.choice(cand, min(-diff, 5000), replace=False); n[ix] -= 1
cidx = np.repeat(np.arange(N_CUST), n); M = len(cidx)
sd = sday[cidx]
day = np.clip(np.searchsorted(cdf, cdf0[sd] + rng.random(M) * (1 - cdf0[sd])), sd, T - 1)
first = np.r_[True, cidx[1:] != cidx[:-1]]
day[first] = np.minimum(sd[first] + rng.geometric(.2, M)[first] - 1, T - 1)
o = np.argsort(day, kind='stable'); cidx, day = cidx[o], day[o]
tc = tcode_c[cidx]
PAYM = ['UPI', 'COD', 'Credit Card', 'Debit Card', 'Net Banking', 'EMI', 'Flipkart Pay Later', 'Wallet']
PROB = np.array([[.50, .12, .14, .10, .04, .05, .03, .02], [.48, .17, .12, .10, .04, .04, .03, .02],
                 [.45, .25, .09, .10, .04, .03, .02, .02], [.38, .38, .05, .10, .03, .02, .02, .02]])
pay = np.empty(M, dtype=object)
for t in range(4):
    m = tc == t; pay[m] = rng.choice(PAYM, m.sum(), p=PROB[t])
oev = ev[day]; is_ev = oev != 'None'
oid = rng.integers(10 ** 17, 10 ** 18 - 1, M)
while len(np.unique(oid)) != M: oid = rng.integers(10 ** 17, 10 ** 18 - 1, M)
order_id = np.array([f"OD{x}" for x in oid], dtype=object)

cnt = rng.choice([1, 2, 3, 4, 5], M, p=[.45, .30, .14, .07, .04]); L = int(cnt.sum())
io = np.repeat(np.arange(M), cnt); starts = np.r_[0, np.cumsum(cnt)[:-1]]
pidx = rng.choice(P, L, p=pp)
qty = np.where(cat_idx[pidx] == CAT_ORDER.index('Grocery'), rng.choice([1, 2, 3, 4], L, p=[.5, .3, .12, .08]), rng.choice([1, 2, 3, 4], L, p=[.86, .10, .03, .01]))
iday = day[io]
drift = 0.965 ** ((T - 1 - iday) / 365.25)
ev_f = np.where(is_ev[io], rng.uniform(.82, .97, L), 1.0)
unit = np.maximum(np.rint(prod.selling_price.to_numpy()[pidx] * drift * rng.uniform(.93, 1.02, L) * ev_f), 29).astype(int)
sub = np.bincount(io, weights=unit * qty, minlength=M)
dflag = rng.random(M) < np.where(is_ev, .8, .45)
disc = np.where(dflag, np.minimum(np.rint(sub * rng.uniform(.02, .15, M)), 2000), 0).astype(int)
total = (sub - disc).astype(int)

canc = rng.random(M) < np.where(pay == 'COD', .09, .045)
lo_d, hi_d = np.array([1, 2, 3, 4]), np.array([4, 5, 7, 10])
ship = lo_d[tc] + np.floor(rng.random(M) * (hi_d[tc] - lo_d[tc] + 1)).astype(int) + np.where(is_ev, rng.integers(1, 4, M), 0)
dday = iday + ship[io] + rng.integers(0, 3, L)
odday = np.maximum.reduceat(dday, starts)
notyet = (odday > T - 1) & ~canc
ost = np.where(canc, 'Cancelled', np.where(notyet, np.where((day >= T - 2) & (rng.random(M) < .5), 'Placed', 'Shipped'), 'Delivered')).astype(object)
ist = np.where(canc[io], 'Cancelled', np.where(notyet[io], ost[io], 'Delivered')).astype(object)

# returns
cgrp = np.where(np.isin(cat_idx[pidx], [CAT_ORDER.index(c) for c in ("Men's Fashion", "Women's Fashion", 'Footwear')]), 0,
        np.where(np.isin(cat_idx[pidx], [CAT_ORDER.index(c) for c in ('Mobiles', 'Laptops', 'Electronics', 'Home Appliances')]), 1, 2))
base_p = np.array([.04, .015, .03, .02, .05, .045, .04, .05, .02, .015, .045, .03])  # per CAT_ORDER (relative)
pr_cat = {'Mobiles': .06, 'Laptops': .05, 'Electronics': .08, 'Home Appliances': .07, "Men's Fashion": .16, "Women's Fashion": .20,
          'Footwear': .15, 'Beauty & Grooming': .05, 'Home & Furniture': .08, 'Grocery': .01, 'Toys & Baby': .06, 'Sports & Fitness': .07}
pr = np.array([pr_cat[c] for c in CAT_ORDER])[cat_idx[pidx]] * (ist == 'Delivered')
pr = np.clip(pr * (N_RET / pr.sum()), 0, .7)
isret = rng.random(L) < pr
ri = np.where(isret)[0]; R = len(ri)
rd_raw = dday[ri] + rng.integers(1, 11, R); rd = np.minimum(rd_raw, T - 1)
pend = rd_raw > T - 6
rstat = np.where(pend, rng.choice(['Pickup Scheduled', 'In Process'], R), rng.choice(['Refunded', 'Replaced', 'Rejected'], R, p=[.89, .06, .05])).astype(object)
full = unit[ri] * qty[ri]
refund = np.where(rng.random(R) < .86, full, np.rint(full * rng.uniform(.8, .95, R))).astype(float)
refund[np.isin(rstat, ['Rejected', 'Replaced'])] = 0; refund[pend] = np.nan
REASONS = [(['Size/fit issue', 'Not as described', 'Quality not as expected', 'Changed my mind', 'Wrong item delivered', 'Defective product'], [.38, .14, .16, .14, .06, .12]),
           (['Defective product', 'Not as described', 'Damaged in transit', 'Wrong item delivered', 'Changed my mind', 'Better price available', 'Late delivery'], [.30, .14, .14, .08, .14, .10, .10]),
           (['Damaged in transit', 'Wrong item delivered', 'Quality not as expected', 'Changed my mind', 'Not as described', 'Late delivery', 'Defective product'], [.18, .12, .18, .16, .14, .10, .12])]
reason = np.empty(R, dtype=object)
for g in range(3):
    m = cgrp[ri] == g; reason[m] = rng.choice(REASONS[g][0], m.sum(), p=REASONS[g][1])
ist[ri[rstat != 'Rejected']] = 'Returned'
nret = np.bincount(io[ist == 'Returned'], minlength=M); ncan = np.bincount(io[ist == 'Cancelled'], minlength=M)
ost[(nret > 0) & (nret + ncan == cnt)] = 'Returned'

# reviews
rb = prod.rating.fillna(4.0).to_numpy()[pidx]
has_rev = np.isin(ist, ['Delivered', 'Returned']) & (rng.random(L) < np.where(ist == 'Returned', .22, .30))
rating = np.clip(np.rint(rng.normal(rb - .15, 1.0)), 1, 5).astype(int)
rating = np.where((ist == 'Returned') & (rng.random(L) < .6), np.maximum(rating - rng.integers(1, 3, L), 1), rating)
TPL = {5: ["Excellent {p}! Totally worth the price.", "Paisa vasool {p}, delivery bhi time pe aayi.", "Superb quality, very happy with this {p}.", "Best {p} in this range. Highly recommended!", "Mast product hai, packaging bhi ekdum safe thi.", "Loved it! Exactly as shown in the pictures.", "Great value for money. Flipkart delivery was quick."],
       4: ["Good {p}, does the job well.", "Nice product but delivery was slightly delayed.", "Quality is good for the price. Satisfied.", "Achha hai, bas thoda aur better ho sakta tha.", "Value for money, would buy again.", "Good {p}. Packaging could have been better."],
       3: ["Average {p}, not great not bad.", "Okay product for the price.", "Theek-thaak hai, expectations se thoda kam.", "Product is fine but delivery took long.", "Decent but nothing special."],
       2: ["Not happy with the {p}, quality is below average.", "Quality bahut average hai, paisa waste laga.", "Product looks different from the photos.", "Stopped working properly within a few weeks.", "Delivery was late and packaging was poor."],
       1: ["Worst {p}! Do not buy.", "Bakwas quality, paisa barbaad. Return kar raha hu.", "Received a defective piece. Very disappointed.", "Fake/duplicate product. Total waste of money.", "Terrible experience, customer care also did not help."]}
noun = prod.noun.to_numpy()[pidx]
rtext = np.full(L, None, dtype=object)
for i in np.where(has_rev & (rng.random(L) < .7))[0]:
    rtext[i] = pick(TPL[rating[i]]).format(p=noun[i])
rrating = np.where(has_rev, rating, 0).astype(object); rrating[~has_rev] = None

# ------------------------------------------------------------------ CLEAN EXPORT
# Same seed + same logic as the raw generator, so every customer / product / order / item
# is the SAME record as in the raw set, just without any messiness.
# NULLs kept only where they are logically true:
#   customers.referred_by_customer_id (not referred) | products.rating (no ratings yet)
#   orders.sale_event (no sale event)                 | order_items.delivered_date (cancelled / in transit)
#   order_items.review_rating / review_text (no review) | returns.refund_amount (refund pending)
iso = lambda a: pd.Series(pd.to_datetime(a)).dt.strftime('%Y-%m-%d').to_numpy(object)

customers_c = pd.DataFrame({
    'customer_id': cust_id, 'customer_name': names, 'gender': gender, 'age': age, 'email': emails,
    'city': c_city, 'state': c_state, 'pincode': c_pin, 'tier': c_tier, 'signup_date': iso(DAYS[sday]),
    'is_plus_member': (plus == 'Yes').astype(int), 'referred_by_customer_id': ref})

products_c = prod[['product_id', 'product_name', 'category', 'brand', 'seller_id', 'mrp', 'selling_price', 'rating', 'stock_qty']].copy()

oev_c = np.where(oev == 'None', None, oev).astype(object)
orders_c = pd.DataFrame({
    'order_id': order_id, 'customer_id': cust_id[cidx], 'order_date': iso(DAYS[day]), 'order_status': ost,
    'payment_mode': pay, 'total_amount': total, 'discount_amount': disc, 'sale_event': oev_c})

dmask_c = np.isin(ist, ['Delivered', 'Returned'])
dd_c = np.where(dmask_c, DAYS[np.clip(dday, 0, T - 1)], np.datetime64('NaT', 'ns'))
item_id = np.array([f"OI{100000000000 + i}" for i in range(L)], dtype=object)
order_items_c = pd.DataFrame({
    'order_item_id': item_id, 'order_id': order_id[io], 'product_id': prod.product_id.to_numpy(object)[pidx],
    'seller_id': prod.seller_id.to_numpy(object)[pidx], 'quantity': qty, 'unit_price': unit, 'item_status': ist,
    'delivered_date': iso(dd_c), 'review_rating': pd.Series(rrating).astype('Int64'), 'review_text': rtext})

# return_id: reuse the ids from the raw file when available (so raw and clean rows match); make them unique
ret_id = np.array([f"RTN{rng.integers(10 ** 8, 10 ** 9 - 1)}" for _ in range(R)], dtype=object)
raw_ret = f"/mnt/user-data/outputs/flipkart_raw_data/returns.csv"
if os.path.exists(raw_ret):
    rr_ = pd.read_csv(raw_ret, dtype=str).drop_duplicates()
    m = dict(zip(rr_['order_item_id'], rr_['return_id']))
    ret_id = np.array([m.get(i, r) for i, r in zip(item_id[ri], ret_id)], dtype=object)
seen = set()
for k in range(R):
    while ret_id[k] in seen: ret_id[k] = f"RTN{rng.integers(10 ** 8, 10 ** 9 - 1)}"
    seen.add(ret_id[k])
returns_c = pd.DataFrame({
    'return_id': ret_id, 'order_item_id': item_id[ri], 'return_date': iso(DAYS[rd]), 'return_reason': reason,
    'refund_amount': pd.Series(refund).round(0).astype('Int64'), 'return_status': rstat})

# ------------------------------------------------------------------ INTEGRITY CHECKS
assert customers_c.customer_id.is_unique and products_c.product_id.is_unique and orders_c.order_id.is_unique
assert order_items_c.order_item_id.is_unique and returns_c.return_id.is_unique
assert orders_c.customer_id.isin(customers_c.customer_id).all()
assert order_items_c.order_id.isin(orders_c.order_id).all() and order_items_c.product_id.isin(products_c.product_id).all()
assert returns_c.order_item_id.isin(order_items_c.order_item_id).all()
assert customers_c.referred_by_customer_id.dropna().isin(customers_c.customer_id).all()
assert (products_c.selling_price <= products_c.mrp).all()
chk = order_items_c.assign(line=order_items_c.quantity * order_items_c.unit_price).groupby('order_id').line.sum()
o_ = orders_c.set_index('order_id'); assert ((chk - o_.discount_amount.reindex(chk.index)) == o_.total_amount.reindex(chk.index)).all()
od_ = pd.to_datetime(orders_c.set_index('order_id').order_date).reindex(order_items_c.order_id).to_numpy()
dl_ = pd.to_datetime(order_items_c.delivered_date).to_numpy()
assert (dl_[~pd.isna(dl_)] >= od_[~pd.isna(dl_)]).all()
first_o = pd.to_datetime(orders_c.groupby('customer_id').order_date.min())
sg_ = pd.to_datetime(customers_c.set_index('customer_id').signup_date).reindex(first_o.index)
assert (first_o >= sg_).all()

for nm_, df in [('customers', customers_c), ('products', products_c), ('orders', orders_c), ('order_items', order_items_c), ('returns', returns_c)]:
    df.to_csv(f"{OUT}/{nm_}.csv", index=False)
    print(f"{nm_:12s} rows={len(df):>8,}  nulls={ {c: int(v) for c, v in df.isna().sum().items() if v} }")

print("\n--- JOIN-CONCEPT COVERAGE ---")
print("customers with NO orders (LEFT/RIGHT/anti join):", int((~customers_c.customer_id.isin(orders_c.customer_id)).sum()))
print("products NEVER sold (LEFT/RIGHT/anti join):", int((~products_c.product_id.isin(order_items_c.product_id)).sum()))
print("order_items with NO return:", int((~order_items_c.order_item_id.isin(returns_c.order_item_id)).sum()), "| with return:", len(returns_c))
print("referred customers (SELF join):", int(customers_c.referred_by_customer_id.notna().sum()))
ref_d = customers_c.set_index('customer_id').referred_by_customer_id
depth = {}
def dep(c):
    if c in depth: return depth[c]
    p = ref_d.get(c); depth[c] = 0 if pd.isna(p) else 1 + dep(p); return depth[c]
mx = max(dep(c) for c in customers_c.customer_id)
print("max referral chain depth (recursive CTE):", mx)
print("orders per customer: max", int(orders_c.groupby('customer_id').size().max()), "| median", float(orders_c.groupby('customer_id').size().median()))
print("order statuses:", orders_c.order_status.value_counts().to_dict())
print("date range:", orders_c.order_date.min(), "->", orders_c.order_date.max())
